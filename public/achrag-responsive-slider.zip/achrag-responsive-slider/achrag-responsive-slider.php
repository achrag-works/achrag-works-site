<?php
/**
 * Plugin Name: ACHRAG Responsive Slider
 * Description: Mobile-compatible responsive image slider. Processing powered by ACHRAG Works API. Supervised by jkt.
 * Author: ACHRAG Works (Supervised by jkt)
 * Version: 2.0.0
 */
if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'achrag-client.php';
require_once plugin_dir_path(__FILE__) . 'achrag-admin.php';

$_achrag_slider_client = new ACHRAG_Client('achrag-responsive-slider');
$_achrag_slider_admin  = new ACHRAG_Admin($_achrag_slider_client, 'ACHRAG Responsive Slider');

register_activation_hook(__FILE__, [$_achrag_slider_client, 'on_activate']);

// ── 管理画面設定 ─────────────────────────────────────
add_action('admin_menu', function() {
    add_menu_page('ACHRAG Slider 設定', 'ACHRAG Slider', 'manage_options',
        'achrag-slider-settings', 'achrag_slider_settings_page',
        'dashicons-images-alt2', 25);
});

function achrag_slider_settings_page() {
    if (!current_user_can('manage_options')) return;
    $opts = get_option('achrag_slider_settings', []);
    if (isset($_POST['achrag_slider_save'])) {
        check_admin_referer('achrag_slider_nonce');
        $opts['width']        = absint($_POST['width'] ?? 800);
        $opts['height']       = absint($_POST['height'] ?? 400);
        $opts['duration']     = absint($_POST['duration'] ?? 4);
        $opts['display_type'] = sanitize_text_field($_POST['display_type'] ?? 'carousel');
        $opts['items_to_show']= absint($_POST['items_to_show'] ?? 1);
        $opts['slide_data']   = json_decode(stripslashes($_POST['slide_data'] ?? '[]'), true) ?: [];
        update_option('achrag_slider_settings', $opts);
        echo '<div class="notice notice-success"><p>保存しました。</p></div>';
    }
    ?>
    <div class="wrap">
      <h1>ACHRAG Responsive Slider 設定</h1>
      <form method="post">
        <?php wp_nonce_field('achrag_slider_nonce'); ?>
        <table class="form-table">
          <tr><th>幅 (px)</th><td><input type="number" name="width" value="<?= esc_attr($opts['width']??800) ?>"></td></tr>
          <tr><th>高さ (px)</th><td><input type="number" name="height" value="<?= esc_attr($opts['height']??400) ?>"></td></tr>
          <tr><th>スライド間隔 (秒)</th><td><input type="number" name="duration" value="<?= esc_attr($opts['duration']??4) ?>"></td></tr>
          <tr><th>表示タイプ</th><td>
            <select name="display_type">
              <option value="carousel" <?= selected($opts['display_type']??'carousel','carousel',false) ?>>カルーセル</option>
              <option value="normal"   <?= selected($opts['display_type']??'carousel','normal',false) ?>>通常</option>
            </select>
          </td></tr>
          <tr><th>PC表示枚数</th><td><input type="number" name="items_to_show" min="1" max="4" value="<?= esc_attr($opts['items_to_show']??1) ?>"></td></tr>
        </table>
        <h2>スライド画像</h2>
        <div id="achrag-slide-list"></div>
        <button type="button" class="button" id="achrag-add-slide">画像を追加</button>
        <input type="hidden" name="slide_data" id="achrag-slide-data" value="<?= esc_attr(json_encode($opts['slide_data']??[])) ?>">
        <input type="hidden" name="achrag_slider_save" value="1">
        <?php submit_button('保存する'); ?>
      </form>
    </div>
    <script>
    (function($){
      var slides = <?= json_encode($opts['slide_data']??[]) ?>;
      function renderList(){
        var html=''; slides.forEach(function(s,i){
          html+='<div style="display:flex;gap:10px;align-items:center;margin-bottom:8px;background:#f9f9f9;padding:8px;border:1px solid #ddd;border-radius:4px;">';
          html+='<img src="'+s.url+'" style="width:60px;height:60px;object-fit:cover;">';
          html+='<div><div>URL: <input type="text" value="'+s.link+'" onchange="slides['+i+'].link=this.value;save();" style="width:200px;"></div>';
          html+='<div>Alt: <input type="text" value="'+s.alt+'" onchange="slides['+i+'].alt=this.value;save();" style="width:150px;"></div></div>';
          html+='<button type="button" onclick="slides.splice('+i+',1);renderList();" class="button">削除</button>';
          html+='</div>';
        }); $('#achrag-slide-list').html(html); save();
      }
      function save(){ $('#achrag-slide-data').val(JSON.stringify(slides)); }
      $('#achrag-add-slide').on('click',function(){
        var frame=wp.media({title:'画像を選択',multiple:true});
        frame.on('select',function(){
          frame.state().get('selection').map(function(a){
            a=a.toJSON(); slides.push({id:a.id,url:a.url,link:'',alt:a.alt||''});
          }); renderList();
        }).open();
      });
      renderList();
      wp.media && wp.media.editor && $('#achrag-add-slide').trigger('init');
    })(jQuery);
    </script>
    <?php
    wp_enqueue_media();
}

// ── フロントエンド出力 ───────────────────────────────
add_shortcode('achrag_responsive_slider', 'achrag_slider_render');
add_action('swell_before_main', function(){ if(is_front_page()) echo achrag_slider_render(); });

function achrag_slider_render() {
    global $_achrag_slider_client;
    if (!$_achrag_slider_client->boot()) return '';
    $opts = get_option('achrag_slider_settings', []);
    if (empty($opts['slide_data'])) return '';

    // スライドデータを組み立て（URLのみ渡す、画像ファイル自体はユーザーサーバーから配信）
    $slides = array_map(function($d) {
        return [
            'url'  => wp_get_attachment_url($d['id']) ?: $d['url'],
            'link' => $d['link'] ?? '',
            'alt'  => $d['alt']  ?? '',
        ];
    }, array_values($opts['slide_data']));

    $payload = [
        'slides'       => $slides,
        'width'        => $opts['width']         ?? 800,
        'height'       => $opts['height']        ?? 400,
        'duration'     => $opts['duration']      ?? 4,
        'display_type' => $opts['display_type']  ?? 'carousel',
        'items_to_show'=> $opts['items_to_show'] ?? 1,
    ];

    // トライアル中はローカルフォールバック描画
    if ($_achrag_slider_client->trial_days_left() > 0 && !$_achrag_slider_client->get_license_key()) {
        return achrag_slider_local_render($payload);
    }

    return $_achrag_slider_client->render('slider', $payload);
}

// トライアル中のローカルレンダリング（コアなし・最小実装）
function achrag_slider_local_render($p) {
    if (!$p['slides']) return '';
    $imgs = array_map(fn($s) =>
        '<div style="flex:0 0 100%;display:flex;justify-content:center;padding:10px;">' .
        '<a href="'.esc_url($s['link']??'#').'"><img src="'.esc_url($s['url']).'" alt="'.esc_attr($s['alt']).'" style="max-width:100%;"></a></div>',
        $p['slides']
    );
    return '<div style="overflow:hidden;display:flex;">'.implode('', $imgs).'</div>
            <p style="font-size:.75em;color:#999;text-align:right;">Trial mode — <a href="https://works.achrag.com/purchase">Get full version</a></p>';
}
