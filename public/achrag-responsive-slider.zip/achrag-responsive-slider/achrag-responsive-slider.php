<?php
/**
 * Plugin Name: ACHRAG Responsive Slider
 * Description: Mobile-compatible responsive image slider for WordPress. Supports carousel and normal modes with customizable size and interval. Supervised by jkt. 
 * Author: ACHRAG Works (Supervised by jkt)
 * Version: 1.7.4
 */

if (!defined('ABSPATH')) exit;

class ExoCustomPCSlider {
    private $option_name = 'exo_pc_slider_settings';

    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('swell_before_main', [$this, 'auto_render_slider']);
        add_shortcode('exo_pc_slider', [$this, 'shortcode_render_slider']);
    }

    public function add_admin_menu() {
        add_menu_page('Exomus-Slider 設定', 'Exomus-Slider', 'manage_options', 'exo-slider-settings', [$this, 'settings_page'], 'dashicons-images-alt2', 25);
    }

    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_exo-slider-settings') return;
        wp_enqueue_media();
        wp_enqueue_script('jquery-ui-sortable');
    }

    public function settings_page() {
        if (isset($_POST['save_exo_slider'])) {
            update_option($this->option_name, $_POST['exo_slider']);
            echo '<div class="updated"><p>設定を保存しました。</p></div>';
        }
        $options = wp_parse_args(get_option($this->option_name, []), [
            'width'=>'250','height'=>'350','duration'=>'3','display_type'=>'carousel','items_to_show'=>'1','slide_data'=>[]
        ]);
        ?>
        <div class="wrap">
            <h1>Exomus-Slider 詳細設定 (v1.7.4)</h1>
            <form method="post">
                <table class="form-table">
                    <tr><th>表示形式 (PC/Pad)</th><td>
                        <label><input type="radio" name="exo_slider[display_type]" value="carousel" <?php checked($options['display_type'], 'carousel'); ?>> カルーセル</label><br>
                        <label><input type="radio" name="exo_slider[display_type]" value="normal" <?php checked($options['display_type'], 'normal'); ?>> ノーマル</label>
                    </td></tr>
                    <tr><th>横並び枚数 (PC/Pad)</th><td>
                        <select name="exo_slider[items_to_show]">
                            <?php foreach([1,3,5,7,9] as $n): ?>
                                <option value="<?php echo $n; ?>" <?php selected($options['items_to_show'], $n); ?>><?php echo $n; ?>枚</option>
                            <?php endforeach; ?>
                        </select>
                    </td></tr>
                    <tr><th>画像サイズ(px)</th><td>
                        幅: <input type="number" name="exo_slider[width]" value="<?php echo esc_attr($options['width']); ?>"> 
                        高さ: <input type="number" name="exo_slider[height]" value="<?php echo esc_attr($options['height']); ?>">
                    </td></tr>
                    <tr><th>スライド間隔(秒)</th><td><input type="number" name="exo_slider[duration]" value="<?php echo esc_attr($options['duration']); ?>"> 秒</td></tr>
                </table>
                <button type="button" class="button" id="exo_select_images">画像を追加</button>
                <div id="exo_slide_list" style="margin-top:20px;">
                    <?php 
                    if (!empty($options['slide_data'])) {
                        foreach ($options['slide_data'] as $index => $data) {
                            $this->render_admin_slide_item($index, $data);
                        }
                    } 
                    ?>
                </div>
                <p class="submit"><input type="submit" name="save_exo_slider" class="button-primary" value="設定を保存"></p>
            </form>
        </div>
        <script>
        jQuery(document).ready(function($){
            let slideIndex = $('#exo_slide_list .exo-admin-slide-item').length;
            $('#exo_select_images').click(function(e) {
                e.preventDefault();
                var frame = wp.media({ title: '画像を選択', multiple: true, button: { text: '追加' } });
                frame.on('select', function() {
                    var selection = frame.state().get('selection');
                    selection.map(function(attachment) {
                        attachment = attachment.toJSON();
                        var url = attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;
                        $('#exo_slide_list').append(`
                            <div class="exo-admin-slide-item">
                                <img src="${url}">
                                <div class="exo-admin-slide-fields">
                                    <input type="hidden" name="exo_slider[slide_data][${slideIndex}][id]" value="${attachment.id}">
                                    <label>URL:</label><input type="url" name="exo_slider[slide_data][${slideIndex}][link]">
                                    <label>Alt:</label><input type="text" name="exo_slider[slide_data][${slideIndex}][alt]">
                                    <span class="exo-remove-slide">削除</span>
                                </div>
                            </div>`);
                        slideIndex++;
                    });
                }).open();
            });
            $(document).on('click', '.exo-remove-slide', function() { $(this).closest('.exo-admin-slide-item').remove(); });
            $('#exo_slide_list').sortable();
        });
        </script>
        <style>.exo-admin-slide-item{background:#f9f9f9;border:1px solid #ccc;padding:15px;margin-bottom:10px;display:flex;gap:20px;max-width:800px;}.exo-admin-slide-item img{width:100px;height:100px;object-fit:cover;}.exo-admin-slide-fields{flex-grow:1;}.exo-admin-slide-fields input{width:100%;margin-bottom:5px;}.exo-remove-slide{color:#a00;cursor:pointer;text-decoration:underline;}</style>
        <?php
    }

    private function render_admin_slide_item($index, $data) {
        $img = wp_get_attachment_image_src($data['id'], 'thumbnail');
        $url = $img ? $img[0] : '';
        ?>
        <div class="exo-admin-slide-item">
            <img src="<?php echo esc_url($url); ?>">
            <div class="exo-admin-slide-fields">
                <input type="hidden" name="exo_slider[slide_data][<?php echo $index; ?>][id]" value="<?php echo esc_attr($data['id']); ?>">
                <label>リンク先URL:</label><input type="url" name="exo_slider[slide_data][<?php echo $index; ?>][link]" value="<?php echo esc_url($data['link']); ?>">
                <label>Altテキスト:</label><input type="text" name="exo_slider[slide_data][<?php echo $index; ?>][alt]" value="<?php echo esc_attr($data['alt']); ?>">
                <span class="exo-remove-slide">削除</span>
            </div>
        </div>
        <?php
    }

    public function auto_render_slider() { if (is_front_page()) echo $this->generate_slider_html(); }
    public function shortcode_render_slider() { return $this->generate_slider_html(); }

    private function generate_slider_html() {
        $options = get_option($this->option_name);
        if (empty($options['slide_data'])) return '';

        $width = (int)$options['width'];
        $height = (int)$options['height'];
        $slide_json = [];
        foreach(array_values($options['slide_data']) as $d) {
            $slide_json[] = [
                'full' => $this->render_slide_markup($d, $width, $height, false),
                'clone' => $this->render_slide_markup($d, $width, $height, true)
            ];
        }

        $pc_items = ($options['display_type'] === 'normal') ? (int)$options['items_to_show'] : 1;
        $duration = (int)$options['duration'] * 1000;

        ob_start();
        ?>
        <style>
            .exo-slider-outer { width: 100%; position: relative; margin: 20px 0; padding-bottom: 50px; overflow: hidden; opacity: 0; transition: opacity 0.3s; }
            .exo-slider-outer.loaded { opacity: 1; }
            .exo-slider-container { display: flex; transition: transform 0.6s cubic-bezier(0.45, 0, 0.55, 1); will-change: transform; }
            .exo-slide { flex: 0 0 100%; display: flex; justify-content: center; box-sizing: border-box; padding: 10px; }
            .exo-slide img { width: <?php echo $width; ?>px; height: <?php echo $height; ?>px; object-fit: cover; max-width: 100%; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .exo-dots { position: absolute; bottom: 0; left: 0; right: 0; display: flex; justify-content: center; gap: 12px; height: 30px; align-items: center; }
            .exo-dot { width: 12px; height: 12px; background: #ccc; border-radius: 50%; border: none; cursor: pointer; padding: 0; transition: 0.3s; }
            .exo-dot.active { background: #333; transform: scale(1.3); }
            @media (min-width: 768px) { .exo-slide { flex: 0 0 <?php echo 100 / $pc_items; ?>%; } }
            @media (max-width: 767px) { .exo-slide img { height: auto; aspect-ratio: <?php echo $width; ?>/<?php echo $height; ?>; } }
        </style>

        <section class="exo-slider-outer" id="exoSlider" aria-roledescription="carousel" aria-label="スライダー">
            <div class="exo-slider-container" id="exoContainer" aria-live="polite"></div>
            <div class="exo-dots" role="group" aria-label="スライド選択"></div>
        </section>

        <script>
        (function() {
            const initSlider = () => {
                const slides = <?php echo json_encode($slide_json); ?>;
                if (!slides.length) return;
                
                const outer = document.getElementById('exoSlider');
                const container = document.getElementById('exoContainer');
                const dotWrap = outer.querySelector('.exo-dots');
                
                const show = window.innerWidth < 768 ? 1 : <?php echo $pc_items; ?>;
                const n = slides.length;

                let html = '';
                for(let i = n - show; i < n; i++) html += slides[i].clone;
                slides.forEach((s, i) => {
                    html += s.full;
                    const d = document.createElement('button');
                    d.className = 'exo-dot' + (i === 0 ? ' active' : '');
                    d.setAttribute('aria-label', 'Slide ' + (i+1));
                    d.onclick = () => { if(!busy) { cur = i + show; go(true); } };
                    dotWrap.appendChild(d);
                });
                for(let i = 0; i < show; i++) html += slides[i].clone;
                
                container.innerHTML = html;
                outer.classList.add('loaded');

                let cur = show, busy = false;
                const pos = (anim) => {
                    container.style.transition = anim ? 'transform 0.6s cubic-bezier(0.45, 0, 0.55, 1)' : 'none';
                    container.style.transform = `translateX(-${cur * (100 / show)}%)`;
                };
                const go = (anim) => {
                    busy = true; pos(anim);
                    const idx = (cur - show + n) % n;
                    dotWrap.querySelectorAll('.exo-dot').forEach((d, i) => d.classList.toggle('active', i === idx));
                };
                
                container.addEventListener('transitionend', () => {
                    busy = false;
                    if (cur >= n + show) { cur = show; pos(false); }
                    else if (cur <= 0) { cur = n; pos(false); }
                });

                pos(false);
                setInterval(() => { if(!document.hidden) { cur++; go(true); } }, <?php echo $duration; ?>);
            };

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initSlider);
            } else {
                initSlider();
            }
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    private function render_slide_markup($data, $w, $h, $is_clone) {
        $link = esc_url($data['link'] ?? '');
        $alt = esc_attr($data['alt'] ?? 'Slide');
        $img = wp_get_attachment_image($data['id'], 'full', false, ['style' => "width:{$w}px; height:{$h}px; object-fit:cover;", 'alt' => $alt]);
        $aria = $is_clone ? 'aria-hidden="true"' : 'role="group" aria-roledescription="slide"';
        $tab = $is_clone ? 'tabindex="-1"' : '';
        return "<div class='exo-slide' {$aria}>" . ($link ? "<a href='{$link}' {$tab}>{$img}</a>" : $img) . "</div>";
    }
}
new ExoCustomPCSlider();