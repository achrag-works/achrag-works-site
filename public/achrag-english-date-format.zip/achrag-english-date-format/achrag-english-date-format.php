<?php
/**
 * Plugin Name: ACHRAG English Date Format
 * Description: Applies US-style date format to English-title posts. Validation powered by ACHRAG Works API. Supervised by jkt.
 * Author: ACHRAG Works (Supervised by jkt)
 * Version: 2.0.0
 */
if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'achrag-client.php';
require_once plugin_dir_path(__FILE__) . 'achrag-admin.php';

$_achrag_edf_client = new ACHRAG_Client('achrag-english-date-format');
$_achrag_edf_admin  = new ACHRAG_Admin($_achrag_edf_client, 'ACHRAG English Date Format');

register_activation_hook(__FILE__, [$_achrag_edf_client, 'on_activate']);

// ライセンス確認後にフックを登録
add_action('init', function() {
    global $_achrag_edf_client;
    if (!$_achrag_edf_client->boot()) return;

    $filters = ['get_the_date','get_the_modified_date','get_the_time','get_the_modified_time'];
    foreach ($filters as $f) {
        add_filter($f, 'achrag_edf_force_english', 999, 3);
    }
});

function achrag_edf_force_english($the_date, $format, $post = null) {
    $post = get_post($post);
    if (!$post) return $the_date;
    if (!preg_match('/^[\x20-\x7e]+$/', $post->post_title)) return $the_date;

    $is_modified = strpos(current_filter(), 'modified') !== false;
    $u_time = $is_modified
        ? get_post_modified_time('U', true, $post)
        : get_post_time('U', true, $post);

    return date('M j, Y', $u_time);
}
