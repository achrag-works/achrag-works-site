<?php
/**
 * Plugin Name: ACHRAG English Date Format
 * Description: Automatically applies US-style date format (e.g. Jun 6, 2026) to posts with English-only titles. No admin menu required — works silently in the background. Supervised by jkt.
 * Version: 1.0.3
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class ACHRAG_English_Date_Format {

    public function __construct() {
        // 標準的な日付・時刻フィルターすべてに高優先度でフック
        $filters = array('get_the_date', 'get_the_modified_date', 'get_the_time', 'get_the_modified_time');
        foreach ( $filters as $filter ) {
            add_filter( $filter, array( $this, 'force_english_date' ), 999, 3 );
        }
    }

    public function force_english_date( $the_date, $format, $post = null ) {
        // get_post() で現在の投稿オブジェクトを取得
        $post = get_post( $post );
        
        if ( $post && $this->is_alphabet_only( $post->post_title ) ) {
            // 現在実行されているフィルターが「更新日」に関するものか判定
            $current_f = current_filter();
            $is_modified = ( strpos($current_f, 'modified') !== false );
            
            // タイムスタンプを直接取得
            $u_time = $is_modified ? get_post_modified_time('U', true, $post) : get_post_time('U', true, $post);
            
            // WPの設定を完全に無視して PHP の date() で英語表記を生成
            return date('M j, Y', $u_time);
        }

        return $the_date;
    }

    private function is_alphabet_only( $title ) {
        // タイトルが空でなく、かつ全角文字が含まれていないかチェック
        return !empty($title) && !preg_match('/[^\x20-\x7e]/', $title);
    }
}

new ACHRAG_English_Date_Format();