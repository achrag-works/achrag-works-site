<?php
/**
 * ACHRAG License Client
 * Worker通信・チャレンジ認証・BAN検知の共通クライアント
 */
if (!defined('ABSPATH')) exit;

class ACHRAG_Client {

    const API_BASE   = 'https://achrag-license.igarikawa.workers.dev';
    const CACHE_TTL  = 3600; // チャレンジトークンのWPキャッシュTTL(秒)

    public $slug;

    public function __construct($slug) {
        $this->slug = $slug;
    }

    /**
     * WP起動時に呼ぶ。トライアル中 or 認証済みならtrueを返す。
     */
    public function boot() {
        // 1. トライアルチェック
        if ($this->is_in_trial()) return true;

        // 2. ライセンスキーが未設定
        $key = get_option('achrag_license_key_' . $this->slug);
        if (!$key) return false;

        // 3. ブラックリスト確認（ローカルフラグ）
        if (get_option('achrag_banned_' . $this->slug)) return false;

        // 4. チャレンジトークン取得（キャッシュ優先）
        $token = $this->get_token($key);
        return $token !== false;
    }

    /**
     * Workerにレンダリングを依頼してHTMLを返す
     */
    public function render($plugin, $payload) {
        $key   = get_option('achrag_license_key_' . $this->slug);
        $token = $this->get_token($key);
        if (!$token) return '';

        $response = wp_remote_post(self::API_BASE . '/render', [
            'timeout' => 8,
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => json_encode(compact('token', 'plugin', 'payload')),
        ]);

        if (is_wp_error($response)) return '';

        $body = json_decode(wp_remote_retrieve_body($response), true);

        // トークン消費後は次回のためにキャッシュを破棄
        delete_transient('achrag_token_' . $this->slug);

        return $body['html'] ?? '';
    }

    /**
     * チャレンジトークンを取得（キャッシュ付き）
     */
    private function get_token($license_key) {
        $cached = get_transient('achrag_token_' . $this->slug);
        if ($cached) return $cached;

        $domain = parse_url(home_url(), PHP_URL_HOST);

        $response = wp_remote_post(self::API_BASE . '/challenge', [
            'timeout' => 8,
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => json_encode(compact('license_key', 'domain')),
        ]);

        if (is_wp_error($response)) {
            // 通信障害時：短時間だけ許可（UX配慮）
            return 'offline_grace';
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        // BAN検知 → ローカルフラグを立てて即停止
        if ($code === 403 && in_array($body['error'] ?? '', ['banned', 'domain_mismatch'])) {
            update_option('achrag_banned_' . $this->slug, 1);
            return false;
        }

        if ($code !== 200 || empty($body['token'])) return false;

        // トークンをキャッシュ（TTLはWorker側と合わせる）
        $ttl = min($body['expires_in'] ?? 60, 55);
        set_transient('achrag_token_' . $this->slug, $body['token'], $ttl);

        return $body['token'];
    }

    // ── トライアル ───────────────────────────────────
    private function is_in_trial() {
        $act = get_option('achrag_activation_date_' . $this->slug);
        if (!$act) return true;
        return (time() - intval($act)) < (7 * DAY_IN_SECONDS);
    }

    public function trial_days_left() {
        $act = get_option('achrag_activation_date_' . $this->slug);
        if (!$act) return 7;
        return max(0, 7 - (int)((time() - intval($act)) / DAY_IN_SECONDS));
    }

    public function on_activate() {
        if (!get_option('achrag_activation_date_' . $this->slug)) {
            update_option('achrag_activation_date_' . $this->slug, time());
        }
    }

    // ── 管理画面ヘルパー ────────────────────────────
    public function save_license_key($key) {
        delete_option('achrag_banned_' . $this->slug);
        delete_transient('achrag_token_' . $this->slug);
        update_option('achrag_license_key_' . $this->slug, sanitize_text_field($key));
    }

    public function get_license_key() {
        return get_option('achrag_license_key_' . $this->slug, '');
    }

    public function is_banned() {
        return (bool)get_option('achrag_banned_' . $this->slug);
    }
}
