<?php
/**
 * Plugin Name: ACHRAG Date & SEO Customizer
 * Description: ISO date format post list with SEO optimization. Rendering powered by ACHRAG Works API. Supervised by jkt.
 * Author: ACHRAG Works (Supervised by jkt)
 * Version: 2.0.0
 */
if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'achrag-client.php';
require_once plugin_dir_path(__FILE__) . 'achrag-admin.php';

$_achrag_dsc_client = new ACHRAG_Client('achrag-date-seo-customizer');
$_achrag_dsc_admin  = new ACHRAG_Admin($_achrag_dsc_client, 'ACHRAG Date & SEO Customizer');

register_activation_hook(__FILE__, [$_achrag_dsc_client, 'on_activate']);

// ── 管理画面設定 ─────────────────────────────────────
add_action('admin_menu', function() {
    add_options_page('ACHRAG Date & SEO 設定', 'ACHRAG Date & SEO', 'manage_options',
        'achrag-date-seo-settings', 'achrag_dsc_settings_page');
});

add_action('admin_init', function() {
    register_setting('achrag_dsc_group', 'achrag_sort_by');
    register_setting('achrag_dsc_group', 'achrag_display_mode');
    register_setting('achrag_dsc_group', 'achrag_post_count');
});

function achrag_dsc_settings_page() { ?>
    <div class="wrap">
      <h1>ACHRAG Date & SEO Customizer 設定</h1>
      <form method="post" action="options.php">
        <?php settings_fields('achrag_dsc_group'); do_settings_sections('achrag_dsc_group'); ?>
        <table class="form-table">
          <tr><th>並び順</th><td>
            <select name="achrag_sort_by">
              <option value="modified" <?= selected(get_option('achrag_sort_by','modified'),'modified',false) ?>>更新日順</option>
              <option value="date"     <?= selected(get_option('achrag_sort_by','modified'),'date',false) ?>>投稿日順</option>
            </select>
          </td></tr>
          <tr><th>日付表示モード</th><td>
            <select name="achrag_display_mode">
              <option value="both"     <?= selected(get_option('achrag_display_mode','both'),'both',false) ?>>投稿日＋更新日</option>
              <option value="modified" <?= selected(get_option('achrag_display_mode','both'),'modified',false) ?>>更新日のみ</option>
            </select>
          </td></tr>
          <tr><th>1ページあたりの件数</th><td>
            <input type="number" name="achrag_post_count" value="<?= esc_attr(get_option('achrag_post_count',20)) ?>">
          </td></tr>
        </table>
        <?php submit_button(); ?>
      </form>
    </div>
<?php }

// ── ショートコード ───────────────────────────────────
add_shortcode('achrag_latest', 'achrag_dsc_render');

function achrag_dsc_render() {
    global $_achrag_dsc_client;
    if (!$_achrag_dsc_client->boot()) {
        return '<!-- ACHRAG Date & SEO Customizer: license required -->';
    }

    $paged          = get_query_var('paged') ?: 1;
    $sort_by        = get_option('achrag_sort_by', 'modified');
    $mode           = get_option('achrag_display_mode', 'both');
    $posts_per_page = (int)get_option('achrag_post_count', 20);

    $query = new WP_Query([
        'post_type'      => 'post',
        'post_status'    => 'publish',
        'posts_per_page' => $posts_per_page,
        'paged'          => $paged,
        'orderby'        => $sort_by === 'modified' ? 'modified' : 'date',
        'order'          => 'DESC',
    ]);

    $posts = [];
    while ($query->have_posts()) {
        $query->the_post();
        $posts[] = [
            'title'    => get_the_title(),
            'url'      => get_permalink(),
            'date'     => get_the_date('c'),
            'modified' => get_the_modified_date('c'),
        ];
    }
    wp_reset_postdata();

    // トライアル中はローカルレンダリング
    if ($_achrag_dsc_client->trial_days_left() > 0 && !$_achrag_dsc_client->get_license_key()) {
        return achrag_dsc_local_render($posts, $mode, $query);
    }

    $html = $_achrag_dsc_client->render('seo-list', compact('posts', 'mode'));

    // ページネーション追加
    $html .= achrag_dsc_pagination($query->max_num_pages, $paged);

    return $html;
}

function achrag_dsc_local_render($posts, $mode, $query) {
    $out = '<div class="achrag-latest-list" role="feed">';
    foreach ($posts as $p) {
        $pub = (new DateTime($p['date']))->format('Y-m-d');
        $mod = (new DateTime($p['modified']))->format('Y-m-d');
        $date = $mode === 'both'
            ? "Published: <time>{$pub}</time>　Updated: <time>{$mod}</time>"
            : "Updated: <time>{$mod}</time>";
        $out .= "<article style='margin-bottom:25px;border-bottom:1px solid #333;padding-bottom:15px;'>
            <div><a href='{$p['url']}' style='color:#00e5ff;font-weight:bold;font-size:1.2em;text-decoration:none;'>{$p['title']}</a></div>
            <div style='font-size:.85em;color:#888;margin:8px 0 0;'>{$date}</div>
        </article>";
    }
    $out .= '</div>';
    $out .= '<p style="font-size:.75em;color:#999;text-align:right;">Trial mode — <a href="https://works.achrag.com/purchase">Get full version</a></p>';
    $out .= achrag_dsc_pagination($query->max_num_pages, get_query_var('paged') ?: 1);
    return $out;
}

function achrag_dsc_pagination($max_pages, $paged) {
    if ($max_pages <= 1) return '';
    $links = paginate_links([
        'total'   => $max_pages,
        'current' => $paged,
        'type'    => 'array',
    ]);
    if (!$links) return '';
    return '<nav class="achrag-pagination" style="margin-top:2em;display:flex;gap:8px;flex-wrap:wrap;">'
        . implode('', $links) . '</nav>';
}
