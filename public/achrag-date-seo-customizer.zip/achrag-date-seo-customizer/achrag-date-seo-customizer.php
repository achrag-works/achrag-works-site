<?php
/*
Plugin Name: ACHRAG Date & SEO Customizer
Description: Displays posts in ISO date format (YYYY-MM-DD) with accessibility and SEO optimization. Includes admin settings for sort order, display mode, and posts per page. Supervised by jkt.
Version: 16.6
Author: ACHRAG Works (Supervised by jkt)
*/

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 1. 管理メニューの登録
 */
add_action( 'admin_menu', function() {
    add_options_page( 'ACHRAG Date & SEO 設定', 'ACHRAG Date & SEO', 'manage_options', 'achrag-date-seo-settings', 'achrag_date_seo_settings_page' );
});

/**
 * 2. 設定の登録
 */
add_action( 'admin_init', function() {
    register_setting( 'achrag_date_seo_settings_group', 'achrag_display_mode' );
    register_setting( 'achrag_date_seo_settings_group', 'achrag_post_count' );
    register_setting( 'achrag_date_seo_settings_group', 'achrag_sort_by' );
});

/**
 * 3. 設定画面の出力
 */
function achrag_date_seo_settings_page() {
    ?>
    <div class="wrap">
        <h1>ACHRAG Date & SEO 表示設定</h1>
        <form method="post" action="options.php">
            <?php settings_fields( 'achrag_date_seo_settings_group' ); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">並び替え基準</th>
                    <td>
                        <select name="achrag_sort_by">
                            <option value="modified" <?php selected( get_option('achrag_sort_by'), 'modified' ); ?>>最終更新日順</option>
                            <option value="date" <?php selected( get_option('achrag_sort_by'), 'date' ); ?>>新規投稿日順</option>
                        </select>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">表示内容</th>
                    <td>
                        <select name="achrag_display_mode">
                            <option value="both" <?php selected( get_option('achrag_display_mode'), 'both' ); ?>>Published & Updated</option>
                            <option value="modified" <?php selected( get_option('achrag_display_mode'), 'modified' ); ?>>Updated Only</option>
                        </select>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">1ページあたりの件数</th>
                    <td><input type="number" name="achrag_post_count" value="<?php echo esc_attr( get_option('achrag_post_count', 20) ); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

/**
 * 4. 表示ロジック：ISO式日付・アクセシビリティ・SEO対応
 */
add_shortcode( 'achrag_latest', function() {
    $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
    $mode = get_option( 'achrag_display_mode', 'both' );
    $posts_per_page = (int) get_option( 'achrag_post_count', 20 );
    $sort_by = get_option( 'achrag_sort_by', 'modified' );
    
    // ISO式フォーマット: 2026-01-24
    $format = 'Y-m-d';

    $args = array(
        'post_type'      => 'post',
        'posts_per_page' => $posts_per_page,
        'paged'          => $paged,
        'orderby'        => $sort_by,
        'order'          => 'DESC',
        'post_status'    => 'publish'
    );

    $query = new WP_Query( $args );
    $output = '<div class="achrag-latest-list" role="feed" aria-label="Latest Journal Posts">';

    if ( $query->have_posts() ) {
        // ISO式の場合はロケールに左右されないため、switch_to_localeは不要になりました

        while ( $query->have_posts() ) {
            $query->the_post();
            $output .= '<article class="achrag-post-item" style="margin-bottom: 25px; border-bottom: 1px solid #333; padding-bottom: 15px;">';
            
            // 見出し階層エラー回避
            $output .= '<div class="achrag-post-title" style="margin: 0; line-height: 1.4;">';
            $output .= '<a href="'.get_permalink().'" style="color:#00e5ff; text-decoration:none; font-weight:bold; font-size:1.2em;">'.get_the_title().'</a>';
            $output .= '</div>';

            $output .= '<div class="achrag-post-date" style="font-size:0.85em; color:#888; margin: 8px 0 0 0;">';
            if ( $mode === 'both' ) {
                $output .= 'Published: <time datetime="' . get_the_date('c') . '">' . get_the_date($format) . '</time>　';
            }
            $output .= 'Updated: <time datetime="' . get_the_modified_date('c') . '">' . get_the_modified_date($format) . '</time>';
            $output .= '</div>';

            $output .= '</article>';
        }

        // ページネーション（ユニバーサルデザイン対応）
        if ( $query->max_num_pages > 1 ) {
            $output .= '<nav class="achrag-pagination-nav" aria-label="Journal Page Navigation" style="margin-top: 40px; text-align: center; border-top: 1px solid #333; padding-top: 25px;">';
            
            $output .= '<form action="" method="get" style="display: inline-flex; align-items: center; gap: 10px; justify-content: center; flex-wrap: wrap;">';
            $output .= '<label for="achrag-page-select" style="font-size: 0.9em; color: #888;">Jump to:</label>';
            
            $output .= '<select id="achrag-page-select" name="paged" aria-describedby="page-hint" style="background: #1a1a1a; color: #00e5ff; border: 1px solid #333; padding: 8px 12px; border-radius: 4px; cursor: pointer;">';
            for ( $i = 1; $i <= $query->max_num_pages; $i++ ) {
                $selected = ( $i == $paged ) ? ' selected' : '';
                $current_mark = ( $i == $paged ) ? ' (Current)' : '';
                $output .= '<option value="' . $i . '"' . $selected . '>Page ' . $i . $current_mark . '</option>';
            }
            $output .= '</select>';
            
            $output .= '<button type="submit" style="background: #333; color: #00e5ff; border: 1px solid #00e5ff; padding: 8px 20px; border-radius: 4px; cursor: pointer; font-size: 0.9em; font-weight: bold;">GO</button>';
            $output .= '</form>';
            
            $output .= '<p id="page-hint" style="font-size: 0.75em; color: #555; margin-top: 10px;">Select a page and press GO to refresh the list.</p>';
            $output .= '</nav>';
        }

        wp_reset_postdata();
    } else {
        $output .= '<p>No posts found.</p>';
    }

    $output .= '</div>';
    return $output;
});