<?php
/**
 * ACHRAG License Admin UI
 * 各プラグインから new ACHRAG_Admin($client, $plugin_name) で使用
 */
if (!defined('ABSPATH')) exit;

class ACHRAG_Admin {

    private $client;
    private $name;

    public function __construct(ACHRAG_Client $client, $plugin_name) {
        $this->client = $client;
        $this->name   = $plugin_name;
        add_action('admin_menu',    [$this, 'add_menu']);
        add_action('admin_notices', [$this, 'notices']);
        add_action('admin_post_achrag_save_license_' . $client->slug ?? '', [$this, 'save']);
    }

    public function add_menu() {
        add_options_page(
            $this->name . ' License',
            $this->name . ' License',
            'manage_options',
            'achrag-license-' . $this->get_slug(),
            [$this, 'page']
        );
    }

    public function page() {
        $status = $_GET['status'] ?? '';
        $key    = $this->client->get_license_key();
        $days   = $this->client->trial_days_left();
        $banned = $this->client->is_banned();
        ?>
        <div class="wrap" style="max-width:600px;">
          <h1>🔑 <?= esc_html($this->name) ?> — License</h1>
          <?php if ($status === 'ok'): ?>
            <div class="notice notice-success"><p>✅ ライセンスキーを保存しました。</p></div>
          <?php endif; ?>

          <div style="background:#f0f4ff;border:1px solid #b0c4f8;border-radius:8px;padding:16px 20px;margin:1em 0 2em;">
            <?php if ($banned): ?>
              <p style="color:#c62828;margin:0;">🚫 このライセンスは停止されました。<a href="https://works.achrag.com/purchase" target="_blank">新しいライセンスを購入する →</a></p>
            <?php elseif ($key): ?>
              <p style="color:#1b5e20;margin:0;">✅ ライセンスキー登録済み</p>
            <?php elseif ($days > 0): ?>
              <p style="color:#e65100;margin:0;">⏳ トライアル中 — あと <strong><?= $days ?> 日</strong></p>
            <?php else: ?>
              <p style="color:#c62828;margin:0 0 .8em;">🔒 トライアル終了。キーを入力してください。</p>
              <a href="https://works.achrag.com/purchase" target="_blank" class="button button-primary">💳 ライセンスを購入する</a>
            <?php endif; ?>
          </div>

          <form method="post" action="<?= esc_url(admin_url('admin-post.php')) ?>">
            <input type="hidden" name="action" value="achrag_save_license_<?= esc_attr($this->get_slug()) ?>">
            <?php wp_nonce_field('achrag_nonce_' . $this->get_slug()); ?>
            <table class="form-table">
              <tr>
                <th>ライセンスキー</th>
                <td>
                  <input type="text" name="achrag_license_key"
                    value="<?= esc_attr($key) ?>"
                    placeholder="ACHRAG-XXXX-XXXX-XXXX"
                    style="width:320px;font-family:monospace;">
                </td>
              </tr>
            </table>
            <?php submit_button('保存する'); ?>
          </form>
        </div>
        <?php
    }

    public function save() {
        $slug = $this->get_slug();
        check_admin_referer('achrag_nonce_' . $slug);
        $key = $_POST['achrag_license_key'] ?? '';
        $this->client->save_license_key($key);
        wp_redirect(add_query_arg(['page' => 'achrag-license-' . $slug, 'status' => 'ok'], admin_url('options-general.php')));
        exit;
    }

    public function notices() {
        $days   = $this->client->trial_days_left();
        $key    = $this->client->get_license_key();
        $banned = $this->client->is_banned();
        if ($banned) {
            echo '<div class="notice notice-error"><p><strong>' . esc_html($this->name) . '</strong> は停止されました。<a href="https://works.achrag.com/purchase">ライセンスを購入する →</a></p></div>';
        } elseif (!$key && $days <= 3 && $days > 0) {
            echo '<div class="notice notice-warning"><p><strong>' . esc_html($this->name) . '</strong> — トライアルあと <strong>' . $days . ' 日</strong>。<a href="https://works.achrag.com/purchase">購入する →</a></p></div>';
        } elseif (!$key && $days <= 0) {
            echo '<div class="notice notice-error"><p><strong>' . esc_html($this->name) . '</strong> は無効です。<a href="https://works.achrag.com/purchase">ライセンスを購入する →</a></p></div>';
        }
    }

    private function get_slug() {
        // リフレクションで取得（PHP 8対応）
        return (new ReflectionProperty($this->client, 'slug'))->getValue($this->client);
    }
}
