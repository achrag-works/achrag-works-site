<?php
/**
 * ACHRAG License Client
 * Worker通信・チャレンジ認証・BAN検知の共通クライアント
 * 
 * wp-config.php に以下を追記するとStaging環境に切り替わります：
 *   define('ACHRAG_ENV', 'staging');
 *   define('ACHRAG_STAGING_TOKEN', 'ACHRAG-STAGING-xxxxxx');
 */
if (!defined('ABSPATH')) exit;

class ACHRAG_Client {

    const API_PRODUCTION = 'https://achrag-license.igarikawa.workers.dev';
    const API_STAGING    = 'https://achrag-license-staging.igarikawa.workers.dev';

    public $slug;
    private $api_base;
    private $is_staging;
    private $staging_token;

    public function __construct($slug) {
        $this->slug          = $slug;
        $this->is_staging    = (defined('ACHRAG_ENV') && ACHRAG_ENV === 'staging');
        $this->staging_token = defined('ACHRAG_STAGING_TOKEN') ? ACHRAG_STAGING_TOKEN : '';
        $this->api_base      = $this->is_staging ? self::API_STAGING : self::API_PRODUCTION;
    }

    /** WP起動時に呼ぶ。使用可能ならtrueを返す */
    public function boot() {
        if ($this->is_in_trial()) return true;
        $key = get_option('achrag_license_key_' . $this->slug);
        if (!$key) return false;
        if (get_option('achrag_banned_' . $this->slug)) return false;
        return $this->get_token($key) !== false;
    }

    /** Workerにレンダリングを依頼してHTMLを返す */
    public function render($plugin, $payload) {
        $key   = get_option('achrag_license_key_' . $this->slug);
        $token = $this->get_token($key);
        if (!$token || $token === 'offline_grace') return '';

        $response = wp_remote_post($this->api_base . '/render', [
            'timeout' => 8,
            'headers' => $this->build_headers(),
            'body'    => json_encode(compact('token', 'plugin', 'payload')),
        ]);

        delete_transient('achrag_token_' . $this->slug);
        if (is_wp_error($response)) return '';

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body['html'] ?? '';
    }

    /** チャレンジトークンを取得（キャッシュ付き） */
    private function get_token($license_key) {
        $cached = get_transient('achrag_token_' . $this->slug);
        if ($cached) return $cached;

        $domain = parse_url(home_url(), PHP_URL_HOST);
        $response = wp_remote_post($this->api_base . '/challenge', [
            'timeout' => 8,
            'headers' => $this->build_headers(),
            'body'    => json_encode(compact('license_key', 'domain')),
        ]);

        if (is_wp_error($response)) {
            set_transient('achrag_token_' . $this->slug, 'offline_grace', 300);
            return 'offline_grace';
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code === 403 && in_array($body['error'] ?? '', ['banned', 'domain_mismatch'])) {
            update_option('achrag_banned_' . $this->slug, 1);
            return false;
        }

        if ($code !== 200 || empty($body['token'])) return false;

        $ttl = min($body['expires_in'] ?? 60, 55);
        set_transient('achrag_token_' . $this->slug, $body['token'], $ttl);
        return $body['token'];
    }

    /** リクエストヘッダーを構築（staging時はX-Staging-Tokenを付与） */
    private function build_headers() {
        $headers = ['Content-Type' => 'application/json'];
        if ($this->is_staging && $this->staging_token) {
            $headers['X-Staging-Token'] = $this->staging_token;
        }
        return $headers;
    }

    private function is_in_trial() {
        $act = get_option('achrag_activation_date_' . $this->slug);
        if (!$act) return true;
        return (time() - intval($act)) < (7 * DAY_IN_SECONDS);
    }

    public function trial_days_left() {
        $act = get_option('achrag_activation_date_' . $this->slug);
        if (!$act) return 7;
        return max(0, 7 - (int)((time() - intval($act)) / DAY_IN_SECONDS));
    }

    public function on_activate() {
        if (!get_option('achrag_activation_date_' . $this->slug)) {
            update_option('achrag_activation_date_' . $this->slug, time());
        }
    }

    public function save_license_key($key) {
        delete_option('achrag_banned_' . $this->slug);
        delete_transient('achrag_token_' . $this->slug);
        update_option('achrag_license_key_' . $this->slug, sanitize_text_field($key));
    }

    public function get_license_key() {
        return get_option('achrag_license_key_' . $this->slug, '');
    }

    public function is_banned() {
        return (bool)get_option('achrag_banned_' . $this->slug);
    }

    public function is_staging() {
        return $this->is_staging;
    }
}
